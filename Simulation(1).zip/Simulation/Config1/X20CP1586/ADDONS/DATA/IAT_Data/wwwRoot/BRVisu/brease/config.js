/*global define*/
define({

    font: 'Arial, Helvetica, sans-serif',
    //undefinedTextReturnValue: undefined,
    undefinedTextReturnValue: "undefined key",
    visu: {
        activityCount: false
    },
    ContentCaching: {
        preserveOldValues: true
    },
    themeFolder: 'release/'
});