/*global define*/
define(["brease/core/designer/BaseWidget/ClassInfo"], function (superClassInfo) {

    "use strict";

    return {
        
    };
});